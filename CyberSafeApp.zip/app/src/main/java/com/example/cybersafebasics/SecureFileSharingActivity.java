package com.example.cybersafebasics;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.database.Cursor;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.journeyapps.barcodescanner.BarcodeEncoder;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.security.Key;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class SecureFileSharingActivity extends AppCompatActivity {

    private static final int REQUEST_FILE_PICK = 1;

    private TextView txtFileName, txtGeneratedCode;
    private ImageView qrCodeImage;

    private Uri selectedFileUri;
    private String selectedFileName;
    private String generatedCode;

    private FirebaseStorage storage;
    private FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secure_file_sharing);

        Button btnUploadFile = findViewById(R.id.btnUploadFile);
        Button btnEncryptAndShare = findViewById(R.id.btnEncryptAndShare);
        Button btnGenerateQRCode = findViewById(R.id.btnGenerateQRCode);
        Button btnReceiveFile = findViewById(R.id.btnReceiveFile);
        txtFileName = findViewById(R.id.txtFileName);
        txtGeneratedCode = findViewById(R.id.txtGeneratedCode);
        qrCodeImage = findViewById(R.id.qrCodeImage);

        storage = FirebaseStorage.getInstance();
        firestore = FirebaseFirestore.getInstance();

        btnUploadFile.setOnClickListener(v -> selectFile());
        btnEncryptAndShare.setOnClickListener(v -> encryptAndUploadFile());
        btnGenerateQRCode.setOnClickListener(v -> generateQRCode());

        btnReceiveFile.setOnClickListener(v -> {
            startActivity(new Intent(SecureFileSharingActivity.this, ReceiveFileActivity.class));
        });
    }

    private void selectFile() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        startActivityForResult(intent, REQUEST_FILE_PICK);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_FILE_PICK && resultCode == RESULT_OK && data != null) {
            selectedFileUri = data.getData();
            selectedFileName = getFileNameFromUri(selectedFileUri);
            txtFileName.setText("Selected File: " + selectedFileName);
        }
    }

    private String getFileNameFromUri(Uri uri) {
        String result = null;
        Cursor cursor = getContentResolver().query(uri, null, null, null, null);
        if (cursor != null) {
            int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
            if (nameIndex >= 0 && cursor.moveToFirst()) {
                result = cursor.getString(nameIndex);
            }
            cursor.close();
        }
        return result != null ? result : "file";
    }

    private void encryptAndUploadFile() {
        if (selectedFileUri == null) {
            txtFileName.setText("Please select a file first.");
            return;
        }

        try {
            KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
            keyGenerator.init(256);
            SecretKey secretKey = keyGenerator.generateKey();

            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, secretKey);

            InputStream inputStream = getContentResolver().openInputStream(selectedFileUri);
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            CipherOutputStream cipherOutputStream = new CipherOutputStream(byteArrayOutputStream, cipher);

            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                cipherOutputStream.write(buffer, 0, bytesRead);
            }
            cipherOutputStream.close();
            byte[] encryptedBytes = byteArrayOutputStream.toByteArray();

            // Upload to Firebase
            generatedCode = String.format("%04d", new Random().nextInt(10000));
            String encryptedFileName = selectedFileName + ".enc";
            StorageReference storageRef = storage.getReference().child("encrypted_files/" + encryptedFileName);
            UploadTask uploadTask = storageRef.putBytes(encryptedBytes);

            uploadTask.addOnSuccessListener(taskSnapshot -> storageRef.getDownloadUrl().addOnSuccessListener(downloadUri -> {
                String encodedKey = Base64.getEncoder().encodeToString(secretKey.getEncoded());

                Map<String, Object> data = new HashMap<>();
                data.put("fileName", encryptedFileName);
                data.put("downloadUrl", downloadUri.toString());
                data.put("code", generatedCode);
                data.put("aesKey", encodedKey);

                firestore.collection("shared_files").document(generatedCode)
                        .set(data)
                        .addOnSuccessListener(unused -> txtFileName.setText("File encrypted & uploaded successfully."))
                        .addOnFailureListener(e -> txtFileName.setText("Firestore error: " + e.getMessage()));

                txtGeneratedCode.setText("Generated Code: " + generatedCode);
            })).addOnFailureListener(e -> txtFileName.setText("Upload error: " + e.getMessage()));

        } catch (Exception e) {
            txtFileName.setText("Encryption error: " + e.getMessage());
        }
    }

    private void generateQRCode() {
        if (generatedCode == null || selectedFileName == null) {
            txtGeneratedCode.setText("Please encrypt and upload a file first.");
            return;
        }

        try {
            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            String qrData = "Code:" + generatedCode + ";File:" + selectedFileName + ".enc";
            Bitmap bitmap = barcodeEncoder.encodeBitmap(qrData, BarcodeFormat.QR_CODE, 400, 400);
            qrCodeImage.setImageBitmap(bitmap);
        } catch (WriterException e) {
            txtGeneratedCode.setText("QR Code Error: " + e.getMessage());
        }
    }
}
