package com.example.cybersafebasics;

public class MessageAdapter2 {
}
