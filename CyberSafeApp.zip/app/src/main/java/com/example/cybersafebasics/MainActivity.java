package com.example.cybersafebasics;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.more);  // Using 'more.xml' as the new main layout
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.light_white));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                View decor = window.getDecorView();
                decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            }
        }
        // Top Bar Buttons
        ImageButton backButton = findViewById(R.id.backB);
        ImageButton logOutButton = findViewById(R.id.logOutB);

        // Feature Cards
        CardView passwordChecker = findViewById(R.id.btn_password_checker);
        CardView phishingQuiz = findViewById(R.id.btn_phishing_quiz);
        CardView safeBrowsingTips = findViewById(R.id.btn_tips);
        CardView interviewQuestions = findViewById(R.id.btn_interview_questions);
        CardView fileChecker = findViewById(R.id.btnFileChecker);
        CardView cyberNews = findViewById(R.id.btnCyberNews);
        CardView incidentPlaybook = findViewById(R.id.btnIncidentPlaybook);
        CardView securityChecker = findViewById(R.id.btnSecurityChecker);
        CardView secureFileSharing = findViewById(R.id.btnSecureFileSharing);
        CardView imageSteganography = findViewById(R.id.btnImageSteganography);
        CardView securityTools = findViewById(R.id.btnSecurityTools);
        CardView openMessaging = findViewById(R.id.btnOpenMessaging);

        // Bottom Navigation Buttons
        ImageButton browserButton = findViewById(R.id.sammplebutton);
        ImageButton homeButton = findViewById(R.id.Homebutton);
        ImageButton loginButton = findViewById(R.id.loginbutton);

        // Click Listeners for Features
        passwordChecker.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, PasswordCheckerActivity.class)));
        phishingQuiz.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, PhishingQuizActivity.class)));
        safeBrowsingTips.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, TipsActivity.class)));
        interviewQuestions.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, InterviewQuestionsActivity.class)));
        fileChecker.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, FileCheckerActivity.class)));
        cyberNews.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, CyberNewsActivity.class)));
        incidentPlaybook.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, IncidentPlaybookActivity.class)));
        securityChecker.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, SecurityCheckerActivity.class)));
        secureFileSharing.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, SecureFileSharingActivity.class)));
        imageSteganography.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, ImageSteganographyActivity.class)));
        securityTools.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, SecurityToolsActivity.class)));
        openMessaging.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, NxtpageActivity.class)));

        // Top Bar Actions
        backButton.setOnClickListener(v -> finish()); // Navigate back
        logOutButton.setOnClickListener(v -> {
            // Handle logout logic (clear session, redirect to login)
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
            finish();
        });


        // Bottom Navigation Actions
        browserButton.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, SecureBrowserActivity.class)));
        homeButton.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, HomeActivity.class)));
        loginButton.setOnClickListener(v -> startActivity(new Intent(MainActivity.this, ProfileActivity.class)));
    }
}
