package com.example.cybersafebasics;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;

public class TipsActivity extends AppCompatActivity {

    private Spinner categorySpinner;
    private TextView tipsTextView;

    // HashMap to hold tips based on categories
    private HashMap<String, String> tipsMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tips);

        // Initialize UI Components
        categorySpinner = findViewById(R.id.spinner_categories);
        tipsTextView = findViewById(R.id.text_tips);

        // Initialize Tips
        initializeTips();

        // Set up Spinner (Dropdown)
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, tipsMap.keySet().toArray(new String[0]));
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(adapter);

        // Set Spinner item selection listener
        categorySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedCategory = parent.getItemAtPosition(position).toString();
                displayTips(selectedCategory);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                tipsTextView.setText("Select a category to see tips.");
            }
        });
    }

    private void initializeTips() {
        // Initialize tips for each category
        tipsMap = new HashMap<>();

        tipsMap.put("Password Security", "1. Use a strong password with a mix of letters, numbers, and symbols.\n" +
                "2. Avoid using the same password for multiple accounts.\n" +
                "3. Change your passwords regularly.\n" +
                "4. Use a password manager to store your passwords securely.");

        tipsMap.put("Phishing Awareness", "1. Do not click on suspicious links or email attachments.\n" +
                "2. Verify email sender addresses before responding.\n" +
                "3. Avoid sharing personal information over email.\n" +
                "4. Report phishing emails to your IT team.");

        tipsMap.put("Network Security", "1. Use a secure Wi-Fi network with a strong password.\n" +
                "2. Enable firewalls on your network devices.\n" +
                "3. Regularly update router firmware.\n" +
                "4. Avoid using public Wi-Fi for sensitive transactions.");

        tipsMap.put("Malware Protection", "1. Install and update reliable antivirus software.\n" +
                "2. Avoid downloading files from untrusted sources.\n" +
                "3. Regularly scan your system for malware.\n" +
                "4. Keep your operating system and software updated.");

        tipsMap.put("Safe Internet Practices", "1. Use HTTPS websites for secure browsing.\n" +
                "2. Avoid sharing personal information on untrusted websites.\n" +
                "3. Use VPN when accessing the internet from public places.\n" +
                "4. Be cautious while installing browser extensions.");

        tipsMap.put("Two-Factor Authentication", "1. Enable 2FA for all your accounts.\n" +
                "2. Use authenticator apps instead of SMS for 2FA.\n" +
                "3. Backup your recovery codes.\n" +
                "4. Educate yourself about common 2FA bypass techniques.");
    }

    private void displayTips(String category) {
        String tips = tipsMap.get(category);
        tipsTextView.setText(tips);
    }
}
