package com.example.cybersafebasics;

public class NewsItem {
    private String title;
    private String description;
    private String publishedDate;

    public NewsItem(String title, String description, String publishedDate) {
        this.title = title;
        this.description = description;
        this.publishedDate = publishedDate;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getPublishedDate() {
        return publishedDate;
    }
}
