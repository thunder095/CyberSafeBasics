package com.example.cybersafebasics;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.*;
import android.widget.*;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import java.util.*;

public class SecureBrowserActivity extends AppCompatActivity {

    private WebView secureWebView;
    private EditText urlInput;
    private boolean isIncognito = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Enable dark mode
        //AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secure_browser);

        secureWebView = findViewById(R.id.secureWebView);
        urlInput = findViewById(R.id.urlInput);

        setupWebView();

        findViewById(R.id.btnGo).setOnClickListener(v -> loadUrl());
        findViewById(R.id.btnBack).setOnClickListener(v -> {
            if (secureWebView.canGoBack()) secureWebView.goBack();
        });
        findViewById(R.id.btnForward).setOnClickListener(v -> {
            if (secureWebView.canGoForward()) secureWebView.goForward();
        });
        findViewById(R.id.btnRefresh).setOnClickListener(v -> secureWebView.reload());
        findViewById(R.id.btnIncognito).setOnClickListener(v -> toggleIncognito());
    }

    private void setupWebView() {
        WebSettings settings = secureWebView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setCacheMode(WebSettings.LOAD_NO_CACHE);

        secureWebView.clearCache(true);
        secureWebView.clearHistory();

        secureWebView.setWebViewClient(new SecureWebViewClient());
    }

    private void loadUrl() {
        String input = urlInput.getText().toString().trim();
        if (!input.startsWith("http")) {
            input = "https://www.google.com/search?q=" + Uri.encode(input);
        }
        secureWebView.loadUrl(input);
    }

    private void toggleIncognito() {
        isIncognito = !isIncognito;
        Toast.makeText(this, isIncognito ? "Incognito Mode ON" : "Incognito Mode OFF", Toast.LENGTH_SHORT).show();
        secureWebView.clearCache(true);
        secureWebView.clearHistory();
    }

    private static class SecureWebViewClient extends WebViewClient {
        private final List<String> adHosts = Arrays.asList("doubleclick.net", "googlesyndication.com");

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri url = request.getUrl();
            for (String adHost : adHosts) {
                if (url.getHost() != null && url.getHost().contains(adHost)) {
                    return new WebResourceResponse("text/plain", "utf-8", null);
                }
            }

            // Placeholder for Google Safe Browsing or API checks
            if (url.toString().contains("malware") || url.toString().contains("phishing")) {
                return new WebResourceResponse("text/html", "utf-8",
                        new java.io.ByteArrayInputStream(
                                "<h1>⚠️ This site may be unsafe</h1>".getBytes()));
            }

            return super.shouldInterceptRequest(view, request);
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
        }
    }
}
