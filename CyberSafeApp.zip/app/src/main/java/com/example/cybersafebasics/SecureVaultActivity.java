package com.example.cybersafebasics;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.Key;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;

public class SecureVaultActivity extends AppCompatActivity {

    private static final int FILE_SELECT_CODE = 1;
    private TextView txtStatus;
    private String selectedFilePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secure_vault);

        Button btnUploadFile = findViewById(R.id.btninputFile);
        Button btnDecryptFile = findViewById(R.id.btndecryptFile);
        txtStatus = findViewById(R.id.updatestatus);

        btnUploadFile.setOnClickListener(v -> selectFile());
        btnDecryptFile.setOnClickListener(v -> decryptFile());
    }

    private void selectFile() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        startActivityForResult(intent, FILE_SELECT_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_SELECT_CODE && resultCode == Activity.RESULT_OK) {
            if (data != null && data.getData() != null) {
                selectedFilePath = FileUtils.getPath(this, data.getData());
                if (selectedFilePath != null) {
                    encryptFile(selectedFilePath);
                } else {
                    txtStatus.setText("Error: Could not resolve file path.");
                }
            }
        }
    }

    private void encryptFile(String filePath) {
        try {
            // Generate AES key
            KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
            keyGenerator.init(256);
            Key key = keyGenerator.generateKey();

            // Read file
            File file = new File(filePath);
            FileInputStream fis = new FileInputStream(file);
            byte[] fileBytes = new byte[(int) file.length()];
            fis.read(fileBytes);
            fis.close();

            // Encrypt file
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] encryptedBytes = cipher.doFinal(fileBytes);

            // Save encrypted file
            File encryptedFile = new File(getFilesDir(), file.getName() + ".enc");
            FileOutputStream fos = new FileOutputStream(encryptedFile);
            fos.write(encryptedBytes);
            fos.close();

            // Save key
            String keyString = Base64.encodeToString(key.getEncoded(), Base64.DEFAULT);
            File keyFile = new File(getFilesDir(), file.getName() + ".key");
            FileOutputStream keyFos = new FileOutputStream(keyFile);
            keyFos.write(keyString.getBytes());
            keyFos.close();

            txtStatus.setText("File encrypted: " + encryptedFile.getAbsolutePath());
        } catch (Exception e) {
            txtStatus.setText("Error: " + e.getMessage());
        }
    }

    private void decryptFile() {
        try {
            // Assume the user selects an encrypted file and corresponding key
            File encryptedFile = new File(getFilesDir(), "example.txt.enc");
            File keyFile = new File(getFilesDir(), "example.txt.key");

            // Read key
            FileInputStream keyFis = new FileInputStream(keyFile);
            byte[] keyBytes = new byte[(int) keyFile.length()];
            keyFis.read(keyBytes);
            keyFis.close();

            Key key = new SecretKeySpec(Base64.decode(keyBytes, Base64.DEFAULT), "AES");

            // Read encrypted file
            FileInputStream fis = new FileInputStream(encryptedFile);
            byte[] encryptedBytes = new byte[(int) encryptedFile.length()];
            fis.read(encryptedBytes);
            fis.close();

            // Decrypt file
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.DECRYPT_MODE, key);
            byte[] decryptedBytes = cipher.doFinal(encryptedBytes);

            // Save decrypted file
            File decryptedFile = new File(getFilesDir(), "example-decrypted.txt");
            FileOutputStream fos = new FileOutputStream(decryptedFile);
            fos.write(decryptedBytes);
            fos.close();

            txtStatus.setText("File decrypted: " + decryptedFile.getAbsolutePath());
        } catch (Exception e) {
            txtStatus.setText("Error: " + e.getMessage());
        }
    }
}

