package com.example.cybersafebasics;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
public class AppSecurityAnalyzerActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_security_analyzer);

        ListView lvAppPermissions = findViewById(R.id.lvAppPermissions);
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);

        List<String> appInfoList = new ArrayList<>();
        for (ApplicationInfo app : apps) {
            try {
                PackageInfo packageInfo = pm.getPackageInfo(app.packageName, PackageManager.GET_PERMISSIONS);
                if (packageInfo.requestedPermissions != null) {
                    boolean isSensitive = false;
                    StringBuilder permissions = new StringBuilder();
                    for (String permission : packageInfo.requestedPermissions) {
                        permissions.append(permission).append(", ");
                        if (permission.contains("LOCATION") || permission.contains("SMS") || permission.contains("MICROPHONE")) {
                            isSensitive = true;
                        }
                    }
                    String appLabel = app.loadLabel(pm).toString();
                    appInfoList.add(appLabel + " (" + (isSensitive ? "Sensitive Permissions Detected" : "Safe") + "): " + permissions);
                }
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, appInfoList);
        lvAppPermissions.setAdapter(adapter);
    }
}
