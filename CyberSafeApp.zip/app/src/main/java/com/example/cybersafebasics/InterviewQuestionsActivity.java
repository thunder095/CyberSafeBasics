package com.example.cybersafebasics;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class InterviewQuestionsActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private QuestionAnswerAdapter adapter;
    private List<QuestionAnswer> questionAnswerList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interview_questions);

        recyclerView = findViewById(R.id.recyclerView_questions);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Load questions and answers
        questionAnswerList = getInterviewQuestions();
        adapter = new QuestionAnswerAdapter(questionAnswerList);
        recyclerView.setAdapter(adapter);
    }

    private List<QuestionAnswer> getInterviewQuestions() {
        List<QuestionAnswer> questions = new ArrayList<>();

        // Adding 50 high-level cybersecurity questions with answers
        questions.add(new QuestionAnswer("What is zero-trust architecture?", "Zero-trust is a security model where no entity is trusted by default, even inside the network."));
        questions.add(new QuestionAnswer("What is a SIEM system?", "SIEM stands for Security Information and Event Management, providing real-time monitoring, event correlation, and analysis of security alerts."));
        questions.add(new QuestionAnswer("What is a buffer overflow attack?", "A buffer overflow occurs when more data is written to a buffer than it can hold, leading to potential code execution or crashes."));
        questions.add(new QuestionAnswer("Explain the importance of penetration testing.", "Penetration testing identifies vulnerabilities in systems before attackers can exploit them."));
        questions.add(new QuestionAnswer("What are the steps in an incident response plan?", "Steps include Preparation, Identification, Containment, Eradication, Recovery, and Lessons Learned."));
        questions.add(new QuestionAnswer("What is the CIA triad in cybersecurity?", "The CIA triad stands for Confidentiality, Integrity, and Availability."));
        questions.add(new QuestionAnswer("What is the difference between hashing and encryption?", "Hashing is one-way and irreversible, while encryption can be decrypted with the correct key."));
        questions.add(new QuestionAnswer("What is privilege escalation?", "Privilege escalation is gaining elevated access permissions by exploiting vulnerabilities in a system."));
        questions.add(new QuestionAnswer("What are advanced persistent threats (APT)?", "APTs are prolonged, stealthy attacks by sophisticated adversaries targeting sensitive data."));
        questions.add(new QuestionAnswer("How does SSL/TLS secure communication?", "SSL/TLS encrypts communication between client and server, ensuring confidentiality and integrity."));
        questions.add(new QuestionAnswer("What is multi-factor authentication (MFA)?", "MFA is a security method that requires multiple forms of verification, such as a password and an OTP."));
        questions.add(new QuestionAnswer("What is a man-in-the-middle (MITM) attack?", "A MITM attack occurs when an attacker intercepts and relays communications between two parties."));
        questions.add(new QuestionAnswer("What is the difference between IDS and IPS?", "IDS detects potential intrusions, while IPS actively blocks malicious traffic."));
        questions.add(new QuestionAnswer("What is a DDoS attack?", "A Distributed Denial of Service attack floods a system with traffic, making it unavailable to users."));
        questions.add(new QuestionAnswer("What is ransomware?", "Ransomware is a type of malware that encrypts a victim's data and demands payment to restore access."));
        questions.add(new QuestionAnswer("What is the role of a firewall?", "A firewall monitors and filters incoming and outgoing traffic based on security rules."));
        questions.add(new QuestionAnswer("What is phishing?", "Phishing is a social engineering attack where attackers trick individuals into revealing sensitive information."));
        questions.add(new QuestionAnswer("Explain social engineering.", "Social engineering manipulates people into performing actions or divulging confidential information."));
        questions.add(new QuestionAnswer("What is SQL injection?", "SQL injection is an attack that allows attackers to manipulate SQL queries to access unauthorized data."));
        questions.add(new QuestionAnswer("What is the difference between black-box and white-box testing?", "Black-box testing tests functionality without knowledge of internal code, while white-box testing involves full access to the code."));
        questions.add(new QuestionAnswer("What are the OWASP Top 10?", "The OWASP Top 10 is a list of the most critical web application security risks."));
        questions.add(new QuestionAnswer("What is a security patch?", "A security patch is a software update that fixes vulnerabilities or bugs in a system."));
        questions.add(new QuestionAnswer("What is the difference between symmetric and asymmetric encryption?", "Symmetric encryption uses one key for encryption and decryption, while asymmetric encryption uses a public and private key."));
        questions.add(new QuestionAnswer("What is a honeypot?", "A honeypot is a decoy system set up to lure attackers and analyze their activities."));
        questions.add(new QuestionAnswer("What is data exfiltration?", "Data exfiltration is the unauthorized transfer of sensitive data out of a network."));
        questions.add(new QuestionAnswer("What is the principle of least privilege?", "It ensures that users or systems are granted only the minimum access required to perform tasks."));
        questions.add(new QuestionAnswer("What are some common types of malware?", "Common types include viruses, worms, Trojans, ransomware, and spyware."));
        questions.add(new QuestionAnswer("What is an XSS attack?", "Cross-site scripting (XSS) injects malicious scripts into web pages viewed by users."));
        questions.add(new QuestionAnswer("What is a digital certificate?", "A digital certificate is used to verify the authenticity of entities in communication using cryptographic keys."));
        questions.add(new QuestionAnswer("What is a brute-force attack?", "A brute-force attack systematically tries all possible passwords until the correct one is found."));
        questions.add(new QuestionAnswer("What is a rainbow table?", "A rainbow table is a precomputed table of hashes used to crack passwords efficiently."));
        questions.add(new QuestionAnswer("What is sandboxing in cybersecurity?", "Sandboxing isolates a program or process to prevent it from affecting other parts of the system."));
        questions.add(new QuestionAnswer("What is a backdoor?", "A backdoor is a secret entry point that bypasses normal authentication mechanisms."));
        questions.add(new QuestionAnswer("What is network segmentation?", "Network segmentation divides a network into smaller parts to limit the spread of cyberattacks."));
        questions.add(new QuestionAnswer("What is spyware?", "Spyware is malicious software that monitors and collects user information without consent."));
        questions.add(new QuestionAnswer("What is a rootkit?", "A rootkit is a type of malware that hides its presence and provides administrative access to a system."));
        questions.add(new QuestionAnswer("What are security tokens?", "Security tokens are hardware or software devices used for authentication."));
        questions.add(new QuestionAnswer("What is end-to-end encryption?", "End-to-end encryption ensures that only the communicating users can decrypt the messages."));
        questions.add(new QuestionAnswer("What is cyber threat intelligence?", "It involves gathering and analyzing data to identify potential cyber threats."));
        questions.add(new QuestionAnswer("What is threat hunting?", "Threat hunting proactively searches for undetected cyber threats in systems."));
        questions.add(new QuestionAnswer("What is the role of patch management?", "Patch management ensures that software updates and security patches are applied to systems."));
        questions.add(new QuestionAnswer("What is spear phishing?", "Spear phishing is a targeted phishing attack aimed at specific individuals or organizations."));
        questions.add(new QuestionAnswer("What is a secure coding practice?", "Secure coding involves writing software in a way that protects it from vulnerabilities."));
        questions.add(new QuestionAnswer("What is DNS spoofing?", "DNS spoofing tricks a DNS server into returning incorrect IP addresses, redirecting traffic to malicious sites."));
        questions.add(new QuestionAnswer("What is a botnet?", "A botnet is a network of compromised devices controlled by an attacker for malicious purposes."));
        questions.add(new QuestionAnswer("What is encryption at rest?", "Encryption at rest protects data stored on devices or servers by converting it into unreadable formats."));
        questions.add(new QuestionAnswer("What are indicators of compromise (IoCs)?", "IoCs are pieces of evidence that suggest a system has been compromised."));
        questions.add(new QuestionAnswer("What is session hijacking?", "Session hijacking exploits a valid session to gain unauthorized access to a system."));

// Add more questions as needed...

        // Total: 50 questions
        for (int i = 55; i <= 50; i++) {
            questions.add(new QuestionAnswer("Advanced Cybersecurity Question " + i, "Answer to Question " + i));
        }

        return questions;
    }
}
