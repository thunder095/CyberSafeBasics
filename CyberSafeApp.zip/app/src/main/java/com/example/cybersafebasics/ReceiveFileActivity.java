package com.example.cybersafebasics;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.security.Key;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.spec.SecretKeySpec;

public class ReceiveFileActivity extends AppCompatActivity {

    private EditText editTextEnterCode;
    private TextView txtFileRetrievalStatus;

    private FirebaseFirestore firestore;
    private FirebaseStorage storage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receive_file);

        Button btnScanQRCode = findViewById(R.id.btnScanQRCode);
        Button btnRetrieveFile = findViewById(R.id.btnRetrieveFile);
        editTextEnterCode = findViewById(R.id.editTextEnterCode);
        txtFileRetrievalStatus = findViewById(R.id.txtFileRetrievalStatus);

        firestore = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();

        btnScanQRCode.setOnClickListener(v -> {
            IntentIntegrator integrator = new IntentIntegrator(this);
            integrator.setPrompt("Scan QR code from sender");
            integrator.setOrientationLocked(false);
            integrator.initiateScan();
        });

        btnRetrieveFile.setOnClickListener(v -> {
            String enteredCode = editTextEnterCode.getText().toString().trim();
            if (enteredCode.length() != 4) {
                txtFileRetrievalStatus.setText("Enter a valid 4-digit code.");
                return;
            }
            fetchMetadataAndDownload(enteredCode);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null && result.getContents() != null) {
            String qrData = result.getContents();
            if (qrData.contains("Code:")) {
                String code = qrData.split("Code:")[1].split(";")[0];
                fetchMetadataAndDownload(code);
            } else {
                txtFileRetrievalStatus.setText("Invalid QR code.");
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private void fetchMetadataAndDownload(String code) {
        firestore.collection("shared_files").document(code)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        String fileName = documentSnapshot.getString("fileName");
                        String fileUrl = documentSnapshot.getString("downloadUrl");

                        if (fileName != null && fileUrl != null) {
                            downloadAndDecryptFile(code, fileName);
                        } else {
                            txtFileRetrievalStatus.setText("Incomplete metadata.");
                        }
                    } else {
                        txtFileRetrievalStatus.setText("No file found for this code.");
                    }
                })
                .addOnFailureListener(e ->
                        txtFileRetrievalStatus.setText("Firestore error: " + e.getMessage()));
    }

    private void downloadAndDecryptFile(String code, String fileName) {
        StorageReference fileRef = storage.getReference().child("encrypted_files/" + fileName);

        try {
            File localFile = new File(getExternalFilesDir(null), fileName);
            FileOutputStream outputStream = new FileOutputStream(localFile);

            fileRef.getStream((taskSnapshot, inputStream) -> {
                try {
                    // Create AES Key
                    byte[] keyBytes = code.getBytes("UTF-8");
                    if (keyBytes.length < 16) {
                        // Pad the key to 16 bytes if it's shorter
                        byte[] paddedKey = new byte[16];
                        System.arraycopy(keyBytes, 0, paddedKey, 0, keyBytes.length);
                        keyBytes = paddedKey;
                    }

                    Key key = new SecretKeySpec(keyBytes, "AES");
                    Cipher cipher = Cipher.getInstance("AES");
                    cipher.init(Cipher.DECRYPT_MODE, key);

                    CipherInputStream cis = new CipherInputStream(inputStream, cipher);
                    byte[] buffer = new byte[1024];
                    int bytesRead;

                    while ((bytesRead = cis.read(buffer)) != -1) {
                        outputStream.write(buffer, 0, bytesRead);
                    }

                    cis.close();
                    outputStream.close();

                    runOnUiThread(() -> txtFileRetrievalStatus.setText("Decrypted & saved: " + localFile.getAbsolutePath()));
                } catch (Exception e) {
                    runOnUiThread(() -> txtFileRetrievalStatus.setText("Decryption failed: " + e.getMessage()));
                    e.printStackTrace();
                }
            }).addOnFailureListener(e ->
                    txtFileRetrievalStatus.setText("Download error: " + e.getMessage()));

        } catch (Exception e) {
            txtFileRetrievalStatus.setText("File handling error: " + e.getMessage());
            e.printStackTrace();
        }
    }

}
