package com.example.cybersafebasics;

import android.os.Bundle;
import android.widget.ExpandableListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class IncidentPlaybookActivity extends AppCompatActivity {

    private ExpandableListView expandableListView;
    private PlaybookAdapter playbookAdapter;
    private List<String> incidentTypes;
    private HashMap<String, List<String>> responseSteps;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_incident_playbook);

        expandableListView = findViewById(R.id.expandableListView);
        initializePlaybookData();

        playbookAdapter = new PlaybookAdapter(this, incidentTypes, responseSteps);
        expandableListView.setAdapter(playbookAdapter);
    }

    private void initializePlaybookData() {
        incidentTypes = new ArrayList<>();
        responseSteps = new HashMap<>();

        // Add Incident Types
        incidentTypes.add("Malware Attack");
        incidentTypes.add("Phishing Incident");
        incidentTypes.add("Data Breach");
        incidentTypes.add("Insider Threat");
        incidentTypes.add("Ransomware Attack");

        // Add Response Steps
        List<String> malwareSteps = new ArrayList<>();
        malwareSteps.add("1. Isolate the affected system.");
        malwareSteps.add("2. Identify the type of malware.");
        malwareSteps.add("3. Run anti-malware tools.");
        malwareSteps.add("4. Remove the malware and restore backups.");
        malwareSteps.add("5. Conduct a root cause analysis.");

        List<String> phishingSteps = new ArrayList<>();
        phishingSteps.add("1. Identify the scope of the phishing attack.");
        phishingSteps.add("2. Block malicious links in emails.");
        phishingSteps.add("3. Notify affected users.");
        phishingSteps.add("4. Train employees to recognize phishing.");
        phishingSteps.add("5. Implement email filtering solutions.");

        List<String> dataBreachSteps = new ArrayList<>();
        dataBreachSteps.add("1. Identify breached systems and data.");
        dataBreachSteps.add("2. Contain the breach to prevent further access.");
        dataBreachSteps.add("3. Notify affected parties and regulators.");
        dataBreachSteps.add("4. Remediate vulnerabilities.");
        dataBreachSteps.add("5. Review and strengthen security policies.");

        List<String> insiderThreatSteps = new ArrayList<>();
        insiderThreatSteps.add("1. Identify suspicious insider activities.");
        insiderThreatSteps.add("2. Restrict access to sensitive data.");
        insiderThreatSteps.add("3. Monitor and log user behavior.");
        insiderThreatSteps.add("4. Take disciplinary actions if necessary.");
        insiderThreatSteps.add("5. Educate employees about security policies.");

        List<String> ransomwareSteps = new ArrayList<>();
        ransomwareSteps.add("1. Disconnect affected systems from the network.");
        ransomwareSteps.add("2. Do not pay the ransom initially.");
        ransomwareSteps.add("3. Restore data from backups.");
        ransomwareSteps.add("4. Run anti-malware tools to remove ransomware.");
        ransomwareSteps.add("5. Strengthen defenses to prevent future attacks.");

        responseSteps.put(incidentTypes.get(0), malwareSteps);
        responseSteps.put(incidentTypes.get(1), phishingSteps);
        responseSteps.put(incidentTypes.get(2), dataBreachSteps);
        responseSteps.put(incidentTypes.get(3), insiderThreatSteps);
        responseSteps.put(incidentTypes.get(4), ransomwareSteps);
    }
}
