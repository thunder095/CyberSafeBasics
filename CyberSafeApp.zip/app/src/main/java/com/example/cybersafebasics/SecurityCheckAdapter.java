package com.example.cybersafebasics;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class SecurityCheckAdapter extends BaseAdapter {

    private Context context;
    private List<SecurityCheck> checks;

    public SecurityCheckAdapter(Context context, List<SecurityCheck> checks) {
        this.context = context;
        this.checks = checks;
    }

    @Override
    public int getCount() {
        return checks.size();
    }

    @Override
    public Object getItem(int position) {
        return checks.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(android.R.layout.simple_list_item_2, parent, false);
        }

        SecurityCheck check = checks.get(position);
        TextView title = convertView.findViewById(android.R.id.text1);
        TextView description = convertView.findViewById(android.R.id.text2);

        title.setText(check.getTitle());
        description.setText(check.getDescription());

        return convertView;
    }
}
