package com.example.cybersafebasics;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class CybercrimeStatsActivity extends AppCompatActivity {

    BarChart barChart;
    PieChart pieChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cybercrime_stats);

        barChart = findViewById(R.id.barChart);
        pieChart = findViewById(R.id.pieChart);

        loadAndDisplayData();
    }

    private void loadAndDisplayData() {
        try {
            // Load JSON from assets
            InputStream is = getAssets().open("cybercrime_stats.json");
            byte[] buffer = new byte[is.available()];
            is.read(buffer);
            is.close();
            String json = new String(buffer, StandardCharsets.UTF_8);

            JSONObject jsonObject = new JSONObject(json);

            JSONArray yearlyArray = jsonObject.getJSONArray("yearly");
            JSONArray typesArray = jsonObject.getJSONArray("types");

            // Bar chart: Yearly stats
            ArrayList<BarEntry> barEntries = new ArrayList<>();
            ArrayList<String> years = new ArrayList<>();
            for (int i = 0; i < yearlyArray.length(); i++) {
                JSONObject obj = yearlyArray.getJSONObject(i);
                barEntries.add(new BarEntry(i, obj.getInt("cases")));
                years.add(obj.getString("year"));
            }
            BarDataSet barDataSet = new BarDataSet(barEntries, "Cybercrime Cases");
            barDataSet.setColors(new int[]{R.color.purple_500}, this);
            barDataSet.setValueTextSize(12f);
            BarData barData = new BarData(barDataSet);
            barChart.setData(barData);
            XAxis xAxis = barChart.getXAxis();
            xAxis.setValueFormatter(new com.github.mikephil.charting.formatter.ValueFormatter() {
                @Override
                public String getFormattedValue(float value) {
                    int index = (int) value;
                    if (index >= 0 && index < years.size()) {
                        return years.get(index);
                    } else {
                        return "";
                    }
                }
            });

            xAxis.setGranularity(1f);
            xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
            barChart.getDescription().setText("Year-wise Cases");
            barChart.animateY(1000);
            barChart.invalidate();

            // Pie chart: Type-wise stats
            ArrayList<PieEntry> pieEntries = new ArrayList<>();
            for (int i = 0; i < typesArray.length(); i++) {
                JSONObject obj = typesArray.getJSONObject(i);
                pieEntries.add(new PieEntry(obj.getInt("cases"), obj.getString("type")));
            }
            PieDataSet pieDataSet = new PieDataSet(pieEntries, "Crime Type");
            pieDataSet.setColors(new int[]{
                    R.color.teal_200, R.color.purple_700, R.color.purple_500,
                    R.color.black, R.color.light_blue
            }, this);
            PieData pieData = new PieData(pieDataSet);
            pieData.setValueTextSize(12f);
            pieChart.setData(pieData);
            pieChart.getDescription().setText("Type-wise Distribution");
            pieChart.animateY(1000);
            pieChart.invalidate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

