package com.example.cybersafebasics;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
public class SpywareInfoActivity extends AppCompatActivity {

    private RecyclerView rvSuspiciousApps;
    private SuspiciousAppAdapter adapter;
    private List<String> suspiciousAppsList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_spyware);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        MaterialButton btnScan = findViewById(R.id.btnScan);
        rvSuspiciousApps = findViewById(R.id.rvSuspiciousApps);

        rvSuspiciousApps.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SuspiciousAppAdapter(suspiciousAppsList, this);
        rvSuspiciousApps.setAdapter(adapter);

        btnScan.setOnClickListener(v -> checkInstalledApps());

        createNotificationChannel();

        // Start the background spyware detection service
        Intent serviceIntent = new Intent(this, SpywareDetectionService.class);
        startService(serviceIntent);
    }

    private void checkInstalledApps() {
        suspiciousAppsList.clear();
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);

        List<String> suspiciousPermissions = Arrays.asList(
                android.Manifest.permission.READ_SMS,
                android.Manifest.permission.READ_CALL_LOG,
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.RECORD_AUDIO,
                android.Manifest.permission.USE_FULL_SCREEN_INTENT
        );

        for (ApplicationInfo app : apps) {
            try {
                PackageInfo packageInfo = pm.getPackageInfo(app.packageName, PackageManager.GET_PERMISSIONS);
                if (packageInfo.requestedPermissions != null) {
                    for (String permission : packageInfo.requestedPermissions) {
                        if (suspiciousPermissions.contains(permission)) {
                            String appName = pm.getApplicationLabel(app).toString();
                            suspiciousAppsList.add(appName + " - " + app.packageName);
                            break;
                        }
                    }
                }
            } catch (PackageManager.NameNotFoundException e) {
                e.printStackTrace();
            }
        }

        adapter.notifyDataSetChanged();

        if (suspiciousAppsList.isEmpty()) {
            Toast.makeText(this, "No spyware detected!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Spyware detected! Check the list.", Toast.LENGTH_LONG).show();
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "SPYWARE_ALERT",
                    "Spyware Alerts",
                    NotificationManager.IMPORTANCE_HIGH
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
    }
}