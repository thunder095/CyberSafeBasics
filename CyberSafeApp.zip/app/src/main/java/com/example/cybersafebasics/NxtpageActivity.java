package com.example.cybersafebasics;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

public class NxtpageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.more2);  // Using 'more.xml' as the new main layout
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.setStatusBarColor(ContextCompat.getColor(this, R.color.light_white));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                View decor = window.getDecorView();
                decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            }
        }

        // Top Bar Buttons
        ImageButton backButton = findViewById(R.id.backB);
        ImageButton logOutButton = findViewById(R.id.logOutB);

        // Feature Cards
        CardView aiChat = findViewById(R.id.btnAIChat);
        CardView spywareInfo = findViewById(R.id.btnspyware);
        CardView cyberCrime = findViewById(R.id.morechat);
        CardView previousOption = findViewById(R.id.PreviousButton);


        // Bottom Navigation Buttons
        ImageButton browserButton = findViewById(R.id.sammplebutton);
        ImageButton homeButton = findViewById(R.id.Homebutton);
        ImageButton loginButton = findViewById(R.id.loginbutton);

        // Click Listeners for Features
        aiChat.setOnClickListener(v -> startActivity(new Intent(NxtpageActivity.this, ChatBotActivity.class)));
        spywareInfo.setOnClickListener(v -> startActivity(new Intent(NxtpageActivity.this, SpywareInfoActivity.class)));
        cyberCrime.setOnClickListener(v -> startActivity(new Intent(NxtpageActivity.this, CybercrimeStatsActivity.class)));
        previousOption.setOnClickListener(v -> startActivity(new Intent(NxtpageActivity.this, MainActivity.class)));

        // Top Bar Actions
        backButton.setOnClickListener(v -> finish()); // Navigate back
        logOutButton.setOnClickListener(v -> {
            // Handle logout logic (clear session, redirect to login)
            startActivity(new Intent(NxtpageActivity.this, LoginActivity.class));
            finish();
        });


        // Bottom Navigation Actions
        browserButton.setOnClickListener(v -> startActivity(new Intent(NxtpageActivity.this, SecureBrowserActivity.class)));
        homeButton.setOnClickListener(v -> startActivity(new Intent(NxtpageActivity.this, MainActivity.class)));
        loginButton.setOnClickListener(v -> startActivity(new Intent(NxtpageActivity.this, ProfileActivity.class)));
    }
}


