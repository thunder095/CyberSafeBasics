package com.example.cybersafebasics;
import java.util.List;

public class NewsResponse {
    private List<Article> articles;

    public List<Article> getArticles() {
        return articles;
    }

    public static class Article {
        private String title;
        private String description;
        private String publishedAt;

        public String getTitle() {
            return title;
        }

        public String getDescription() {
            return description;
        }

        public String getPublishedAt() {
            return publishedAt;
        }
    }
}


