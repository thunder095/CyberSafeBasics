package com.example.cybersafebasics;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class SecurityCheckerActivity extends AppCompatActivity {

    private ListView listView;
    private SecurityCheckAdapter adapter;
    private List<SecurityCheck> securityChecks;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_security_checker);

        listView = findViewById(R.id.listView);
        securityChecks = new ArrayList<>();

        runSecurityChecks();
        adapter = new SecurityCheckAdapter(this, securityChecks);
        listView.setAdapter(adapter);
    }

    private void runSecurityChecks() {
        // Check USB Debugging
        if (isUsbDebuggingEnabled()) {
            securityChecks.add(new SecurityCheck("USB Debugging Enabled", "Disable USB debugging in developer options to secure your device."));
        } else {
            securityChecks.add(new SecurityCheck("USB Debugging", "Secure - USB debugging is disabled."));
        }

        // Check Device Encryption
        if (!isDeviceEncrypted()) {
            securityChecks.add(new SecurityCheck("Storage Not Encrypted", "Enable encryption to secure your data."));
        } else {
            securityChecks.add(new SecurityCheck("Storage Encryption", "Secure - Device storage is encrypted."));
        }

        // Check Unknown Sources Installation
        if (isUnknownSourcesEnabled()) {
            securityChecks.add(new SecurityCheck("Unknown Sources Enabled", "Disable installation from unknown sources for better security."));
        } else {
            securityChecks.add(new SecurityCheck("Unknown Sources", "Secure - Installation from unknown sources is disabled."));
        }

        // Check Device Updates
        if (!isDeviceUpToDate()) {
            securityChecks.add(new SecurityCheck("Device Updates Missing", "Update your device to the latest version."));
        } else {
            securityChecks.add(new SecurityCheck("Device Updates", "Secure - Device is running the latest OS version."));
        }

        // Check Screen Lock Security
        String screenLockStatus = getScreenLockStatus();
        securityChecks.add(new SecurityCheck("Screen Lock Security", screenLockStatus));
    }

    private boolean isUsbDebuggingEnabled() {
        return Settings.Global.getInt(getContentResolver(), Settings.Global.ADB_ENABLED, 0) == 1;
    }

    private boolean isDeviceEncrypted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            return android.os.Environment.isExternalStorageEmulated();
        }
        return false;
    }

    private boolean isUnknownSourcesEnabled() {
        return Settings.Secure.getInt(getContentResolver(), Settings.Secure.INSTALL_NON_MARKET_APPS, 0) == 1;
    }

    private boolean isDeviceUpToDate() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU; // Example check for latest version
    }

    private String getScreenLockStatus() {
        // Replace with actual implementation to check screen lock type
        return "Secure - Screen lock is set.";
    }
}
