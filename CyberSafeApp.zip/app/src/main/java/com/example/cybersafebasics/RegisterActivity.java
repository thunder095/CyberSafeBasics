package com.example.cybersafebasics;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;

public class RegisterActivity extends AppCompatActivity {

    private EditText etRegUsername, etRegEmail, etRegPassword, etRegConfirmPassword;
    private Button registerButton;
    private TextView signupText;
    private FirebaseAuth mAuth;
    private FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_page);

        mAuth = FirebaseAuth.getInstance();
        firestore = FirebaseFirestore.getInstance();

        etRegUsername = findViewById(R.id.etRegUsername);
        etRegEmail = findViewById(R.id.etRegEmail);
        etRegPassword = findViewById(R.id.etRegPassword);
        etRegConfirmPassword = findViewById(R.id.etRegConfirmPassword);
        registerButton = findViewById(R.id.registerButton);
        signupText = findViewById(R.id.signupText);

        registerButton.setOnClickListener(v -> registerUser());
        signupText.setOnClickListener(v -> {
            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            finish();
        });
    }

    private void registerUser() {
        String username = etRegUsername.getText().toString().trim();
        String email = etRegEmail.getText().toString().trim();
        String password = etRegPassword.getText().toString().trim();
        String confirmPassword = etRegConfirmPassword.getText().toString().trim();

        if (TextUtils.isEmpty(username)) {
            etRegUsername.setError("Username is required");
            return;
        }
        if (TextUtils.isEmpty(email)) {
            etRegEmail.setError("Email is required");
            return;
        }
        if (TextUtils.isEmpty(password)) {
            etRegPassword.setError("Password is required");
            return;
        }
        if (password.length() < 6) {
            etRegPassword.setError("Minimum 6 characters");
            return;
        }
        if (!password.equals(confirmPassword)) {
            etRegConfirmPassword.setError("Passwords don't match");
            return;
        }

        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                HashMap<String, Object> userMap = new HashMap<>();
                userMap.put("username", username);
                userMap.put("email", email);

                firestore.collection("UsersList").document(email).set(userMap)
                        .addOnSuccessListener(aVoid -> {
                            Toast.makeText(RegisterActivity.this, "Registered & Saved!", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                            finish();
                        })
                        .addOnFailureListener(e -> Toast.makeText(RegisterActivity.this, "Failed: " + e.getMessage(), Toast.LENGTH_LONG).show());
            } else {
                Toast.makeText(RegisterActivity.this, "Registration failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}
