package com.example.cybersafebasics;

import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.util.Log;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class FileCheckerActivity extends AppCompatActivity {

    private static final String TAG = "FileCheckerActivity";
    private Uri selectedFileUri;
    private String selectedAlgorithm = "SHA-256";  // Default algorithm

    // Known corrupted file hashes (in different formats)
    private Map<String, Set<String>> knownMalwareHashes = new HashMap<>();

    // UI elements
    private TextView tvSelectedFileName, tvFileHash, tvFileResult, tvKnownMalwareHashes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_checker);

        // Initialize UI elements
        tvSelectedFileName = findViewById(R.id.tvSelectedFileName);
        tvFileHash = findViewById(R.id.tvFileHash);
        tvFileResult = findViewById(R.id.tvFileResult);
        tvKnownMalwareHashes = findViewById(R.id.tvKnownMalwareHashes);

        Button btnSelectFile = findViewById(R.id.btnSelectFile);
        Button btnCheckFile = findViewById(R.id.btnCheckFile);

        // Initialize Spinner for selecting hash algorithms
        Spinner spinnerHashAlgorithm = findViewById(R.id.spinnerHashAlgorithm);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.hash_algorithms, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerHashAlgorithm.setAdapter(adapter);

        spinnerHashAlgorithm.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, android.view.View selectedItemView, int position, long id) {
                selectedAlgorithm = parentView.getItemAtPosition(position).toString();
                Log.d(TAG, "Selected Hash Algorithm: " + selectedAlgorithm);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                selectedAlgorithm = "SHA-256";  // Default value
            }
        });

        // Initialize known malware hashes (example hashes for demonstration)
        initKnownMalwareHashes();

        btnSelectFile.setOnClickListener(v -> openFilePicker());

        // Initially disable the "Check File" button
        btnCheckFile.setEnabled(false);

        btnCheckFile.setOnClickListener(v -> {
            if (selectedFileUri != null) {
                generateFileHash(selectedFileUri);
            } else {
                Toast.makeText(FileCheckerActivity.this, "Please select a file first.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Method to pick a file using the storage access framework
    private void openFilePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("*/*");
        startActivityForResult(intent, 1);
    }

    // Handle the selected file URI and enable the "Check File" button
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == RESULT_OK) {
            if (data != null) {
                selectedFileUri = data.getData();
                Log.d(TAG, "File Selected: " + selectedFileUri);

                // Display the selected file name
                String fileName = getFileName(selectedFileUri);
                tvSelectedFileName.setText("Selected File: " + fileName);

                Button btnCheckFile = findViewById(R.id.btnCheckFile);
                btnCheckFile.setEnabled(true); // Enable the "Check File" button
            }
        }
    }

    // Method to get file name from URI
    private String getFileName(Uri uri) {
        String fileName = null;
        String[] projection = {DocumentsContract.Document.COLUMN_DISPLAY_NAME};
        ContentResolver contentResolver = getContentResolver();
        try (Cursor cursor = contentResolver.query(uri, projection, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                fileName = cursor.getString(cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME));
            }
        }
        return fileName;
    }

    // Method to generate file hash using the selected hash algorithm
    private void generateFileHash(Uri fileUri) {
        try {
            MessageDigest digest = MessageDigest.getInstance(selectedAlgorithm);

            // Use ContentResolver to open an input stream to the file
            InputStream inputStream = getContentResolver().openInputStream(fileUri);
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                digest.update(buffer, 0, bytesRead);
            }
            byte[] hashBytes = digest.digest();
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                hexString.append(Integer.toHexString(0xFF & b));
            }
            String fileHash = hexString.toString();
            Log.d(TAG, "Generated Hash: " + fileHash);

            // Display the generated hash value
            tvFileHash.setText("Hash Value: " + fileHash);

            // Compare the hash and display the result
            compareHash(fileHash);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Method to initialize known malware hashes (for demonstration)
    private void initKnownMalwareHashes() {
        // Example malware hashes for demonstration
        Set<String> sha256Hashes = new HashSet<>();
        sha256Hashes.add("e99a18c428cb38d5f260853678922e03"); // Example hash
        knownMalwareHashes.put("SHA-256", sha256Hashes);

        Set<String> md5Hashes = new HashSet<>();
        md5Hashes.add("d2d2d2d2b2b2b2b2b2b2b2b2b2b2b2b2b"); // Example hash
        knownMalwareHashes.put("MD5", md5Hashes);

        // Update the TextView with known hashes
        tvKnownMalwareHashes.setText("Known Malware Hashes (SHA-256, MD5, etc.):\n" +
                "SHA-256: " + sha256Hashes + "\n" +
                "MD5: " + md5Hashes);
    }

    // Compare the generated hash with known malware hashes
    private void compareHash(String fileHash) {
        Set<String> knownHashes = knownMalwareHashes.get(selectedAlgorithm);
        if (knownHashes != null && knownHashes.contains(fileHash)) {
            tvFileResult.setText("Result: File is corrupted (malware detected).");
        } else {
            tvFileResult.setText("Result: File is safe.");
        }
    }
}
