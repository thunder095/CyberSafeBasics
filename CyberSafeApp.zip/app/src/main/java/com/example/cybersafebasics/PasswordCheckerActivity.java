package com.example.cybersafebasics;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class PasswordCheckerActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_checker);
        EditText passwordInput = findViewById(R.id.input_password);
        TextView resultText = findViewById(R.id.text_result);
        Button checkButton = findViewById(R.id.btn_check);

        checkButton.setOnClickListener(v -> {
            String password = passwordInput.getText().toString();
            String result = checkPasswordStrength(password);
            resultText.setText(result);
        });
    }

    private String checkPasswordStrength(String password) {
        if (password.length() < 8) {
            return "Weak: Password too short!";
        } else if (!password.matches(".*[A-Z].*")) {
            return "Moderate: Add uppercase letters.";
        } else if (!password.matches(".*[!@#$%^&*].*")) {
            return "Strong: Add special characters for better security.";
        } else {
            return "Very Strong: Your password is secure!";
        }
    }
}
