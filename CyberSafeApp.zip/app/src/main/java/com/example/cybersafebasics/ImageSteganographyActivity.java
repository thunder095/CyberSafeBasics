package com.example.cybersafebasics;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.io.InputStream;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class ImageSteganographyActivity extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST = 1;
    private ImageView imageView;
    private Bitmap selectedImage;
    private EditText inputMessage, inputPassword;
    private TextView txtDecodedMessage, txtCapacity;
    private boolean isEncodeMode = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_steganography);

        imageView = findViewById(R.id.imageView);
        inputMessage = findViewById(R.id.inputMessage);
        inputPassword = findViewById(R.id.inputPassword);
        txtDecodedMessage = findViewById(R.id.txtDecodedMessage);
        txtCapacity = findViewById(R.id.txtCapacity);

        findViewById(R.id.btnSelectImage).setOnClickListener(v -> selectImage());
        findViewById(R.id.btnSwitchMode).setOnClickListener(v -> switchMode());
        findViewById(R.id.btnProcess).setOnClickListener(v -> processImage());
    }

    private void selectImage() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    private void switchMode() {
        isEncodeMode = !isEncodeMode;
        inputMessage.setVisibility(isEncodeMode ? View.VISIBLE : View.GONE);
        txtDecodedMessage.setVisibility(isEncodeMode ? View.GONE : View.VISIBLE);
        inputPassword.setHint(isEncodeMode ? "Password for encryption" : "Password for decryption");
        ((Button) findViewById(R.id.btnProcess)).setText(isEncodeMode ? "Encode" : "Decode");
    }

    private void processImage() {
        if (selectedImage == null) {
            Toast.makeText(this, "Please select an image first.", Toast.LENGTH_SHORT).show();
            return;
        }

        String password = inputPassword.getText().toString();
        if (password.isEmpty() || password.length() < 8) {
            Toast.makeText(this, "Password must be at least 8 characters long.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (isEncodeMode) {
            String message = inputMessage.getText().toString();
            if (message.isEmpty()) {
                Toast.makeText(this, "Please enter a message to encode.", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                String encryptedMessage = encryptMessage(message, password);
                Bitmap encodedImage = encodeMessage(selectedImage, encryptedMessage);
                imageView.setImageBitmap(encodedImage);
                Toast.makeText(this, "Message encoded successfully!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to encode message.", Toast.LENGTH_SHORT).show();
            }
        } else {
            try {
                String decodedMessage = decodeMessage(selectedImage);
                String decryptedMessage = decryptMessage(decodedMessage, password);
                txtDecodedMessage.setText("Decoded Message: " + decryptedMessage);
                Toast.makeText(this, "Message decoded successfully!", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to decode message.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private Bitmap encodeMessage(Bitmap bitmap, String message) {
        Bitmap mutableBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);
        byte[] messageBytes = (message + "\0").getBytes();
        int width = mutableBitmap.getWidth();
        int height = mutableBitmap.getHeight();

        int pixelIndex = 0;
        for (byte b : messageBytes) {
            for (int bit = 0; bit < 8; bit++) {
                int x = pixelIndex % width;
                int y = pixelIndex / width;
                if (y >= height) return mutableBitmap;

                int pixel = mutableBitmap.getPixel(x, y);
                int red = (pixel >> 16) & 0xFF;
                int green = (pixel >> 8) & 0xFF;
                int blue = pixel & 0xFF;

                int bitValue = (b >> bit) & 1;
                blue = (blue & 0xFE) | bitValue;

                int newPixel = (0xFF << 24) | (red << 16) | (green << 8) | blue;
                mutableBitmap.setPixel(x, y, newPixel);

                pixelIndex++;
            }
        }
        return mutableBitmap;
    }

    private String decodeMessage(Bitmap bitmap) {
        StringBuilder decodedMessage = new StringBuilder();
        int width = bitmap.getWidth();
        int height = bitmap.getHeight();

        int pixelIndex = 0;
        byte currentByte = 0;
        int bitCount = 0;

        while (true) {
            int x = pixelIndex % width;
            int y = pixelIndex / width;
            if (y >= height) break;

            int pixel = bitmap.getPixel(x, y);
            int blue = pixel & 0xFF;
            currentByte |= (blue & 1) << bitCount;
            bitCount++;

            if (bitCount == 8) {
                if (currentByte == 0) break;
                decodedMessage.append((char) currentByte);
                currentByte = 0;
                bitCount = 0;
            }

            pixelIndex++;
        }

        return decodedMessage.toString();
    }

    private SecretKeySpec generateKey(String password) throws Exception {
        byte[] keyBytes = new byte[16]; // AES 128-bit
        byte[] passwordBytes = password.getBytes("UTF-8");
        System.arraycopy(passwordBytes, 0, keyBytes, 0, Math.min(passwordBytes.length, keyBytes.length));
        return new SecretKeySpec(keyBytes, "AES");
    }

    private String encryptMessage(String message, String password) throws Exception {
        SecretKeySpec key = generateKey(password);
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] encryptedBytes = cipher.doFinal(message.getBytes("UTF-8"));
        return Base64.encodeToString(encryptedBytes, Base64.DEFAULT);
    }

    private String decryptMessage(String encryptedMessage, String password) throws Exception {
        SecretKeySpec key = generateKey(password);
        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, key);
        byte[] decryptedBytes = cipher.doFinal(Base64.decode(encryptedMessage, Base64.DEFAULT));
        return new String(decryptedBytes, "UTF-8");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null) {
            Uri imageUri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(imageUri);
                selectedImage = BitmapFactory.decodeStream(inputStream);
                imageView.setImageBitmap(selectedImage);
                txtCapacity.setText("Max Message Capacity: " + calculateMessageCapacity(selectedImage) + " characters");
            } catch (Exception e) {
                e.printStackTrace();
                Toast.makeText(this, "Failed to load image.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private int calculateMessageCapacity(Bitmap bitmap) {
        return (bitmap.getWidth() * bitmap.getHeight()) / 8;
    }
}
