package com.example.cybersafebasics;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class PhishingQuizActivity extends AppCompatActivity {

    private TextView questionText, resultText, progressText;
    private RadioGroup optionsGroup;
    private Button previousButton, nextButton, submitButton;
    private List<Question> questionList;
    private int currentQuestionIndex = 0;
    private int score = 0;
    private int[] userAnswers;
    private SharedPreferences prefs;

    private String[] tips = {
            "Tip 1: Never share your passwords.",
            "Tip 2: Use two-factor authentication whenever possible.",
            "Tip 3: Keep your software updated to the latest version.",
            "Tip 4: Always check URLs before clicking.",
            "Tip 5: Avoid using public Wi-Fi without a VPN."
    };

    private CountDownTimer timer;
    private long timeLeftInMillis = 60000; // 60 seconds for the quiz

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phishing_quiz);

        questionText = findViewById(R.id.text_question);
        resultText = findViewById(R.id.text_result);
        progressText = findViewById(R.id.text_progress);
        optionsGroup = findViewById(R.id.quiz_group);
        previousButton = findViewById(R.id.btn_previous);
        nextButton = findViewById(R.id.btn_next);
        submitButton = findViewById(R.id.btn_submit);

        prefs = getSharedPreferences("PhishingQuizPrefs", MODE_PRIVATE);

        // Initialize questions and shuffle them
        initializeQuestions();
        Collections.shuffle(questionList);

        userAnswers = new int[questionList.size()];
        for (int i = 0; i < userAnswers.length; i++) userAnswers[i] = -1;

        // Start the timer
        startTimer();

        displayQuestion();

        // Button Listeners
        previousButton.setOnClickListener(v -> navigateQuestion(-1));
        nextButton.setOnClickListener(v -> navigateQuestion(1));
        submitButton.setOnClickListener(v -> {
            saveAnswer();
            calculateScore();
            showScoreCard();
        });
    }

    private void startTimer() {
        timer = new CountDownTimer(timeLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeftInMillis = millisUntilFinished;
                progressText.setText("Time Left: " + millisUntilFinished / 1000 + "s");
            }

            @Override
            public void onFinish() {
                calculateScore();
                showScoreCard();
            }
        }.start();
    }

    private void navigateQuestion(int direction) {
        saveAnswer();
        currentQuestionIndex += direction;
        if (currentQuestionIndex < 0) currentQuestionIndex = 0;
        if (currentQuestionIndex >= questionList.size()) currentQuestionIndex = questionList.size() - 1;
        displayQuestion();
    }

    private void displayQuestion() {
        Question currentQuestion = questionList.get(currentQuestionIndex);
        questionText.setText(currentQuestion.getQuestion());
        ((RadioButton) optionsGroup.getChildAt(0)).setText(currentQuestion.getOption1());
        ((RadioButton) optionsGroup.getChildAt(1)).setText(currentQuestion.getOption2());
        ((RadioButton) optionsGroup.getChildAt(2)).setText(currentQuestion.getOption3());

        optionsGroup.clearCheck();
        if (userAnswers[currentQuestionIndex] != -1) {
            ((RadioButton) optionsGroup.getChildAt(userAnswers[currentQuestionIndex])).setChecked(true);
        }

        progressText.setText("Question " + (currentQuestionIndex + 1) + " of " + questionList.size());
    }

    private void saveAnswer() {
        int selectedId = optionsGroup.getCheckedRadioButtonId();
        if (selectedId != -1) {
            int selectedIndex = optionsGroup.indexOfChild(findViewById(selectedId));
            userAnswers[currentQuestionIndex] = selectedIndex;
        }
    }

    private void calculateScore() {
        score = 0;
        for (int i = 0; i < questionList.size(); i++) {
            if (userAnswers[i] == questionList.get(i).getCorrectAnswer()) score++;
        }
    }

    private void showScoreCard() {
        timer.cancel();

        int highestScore = prefs.getInt("highestScore", 0);
        if (score > highestScore) {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putInt("highestScore", score);
            editor.apply();
            highestScore = score;
        }

        StringBuilder scoreMessage = new StringBuilder();
        scoreMessage.append("Your Score: ").append(score).append("/").append(questionList.size()).append("\n")
                .append("Highest Score: ").append(highestScore).append("\n\n")
                .append("Cybersecurity Tip: ").append(tips[new Random().nextInt(tips.length)]);

        questionText.setText(scoreMessage.toString());
        optionsGroup.setVisibility(View.GONE);
        previousButton.setVisibility(View.GONE);
        nextButton.setVisibility(View.GONE);
        submitButton.setText("Try Again");
        submitButton.setOnClickListener(v -> resetQuiz());
    }

    private void resetQuiz() {
        score = 0;
        currentQuestionIndex = 0;
        for (int i = 0; i < userAnswers.length; i++) userAnswers[i] = -1;

        Collections.shuffle(questionList);
        optionsGroup.setVisibility(View.VISIBLE);
        previousButton.setVisibility(View.VISIBLE);
        nextButton.setVisibility(View.VISIBLE);
        submitButton.setText("Submit");
        startTimer();
        displayQuestion();
    }

    private void initializeQuestions() {
        questionList = new ArrayList<>();

        questionList.add(new Question(
                "What is phishing?",
                "Stealing data", "Cleaning files", "Updating software",
                0, "Phishing is a method to steal personal information by pretending to be a trusted entity."
        ));
        questionList.add(new Question(
                "What is the purpose of a firewall?",
                "Block unauthorized access", "Scan for viruses", "Increase computer speed",
                0, "Firewalls help prevent unauthorized access to a network or system."
        ));
        questionList.add(new Question(
                "What does VPN stand for?",
                "Very Private Network", "Virtual Private Network", "Verified Public Network",
                1, "VPN stands for Virtual Private Network, which secures your internet connection."
        ));
        questionList.add(new Question(
                "What is ransomware?",
                "A file encryption virus", "A backup tool", "A network protector",
                0, "Ransomware is malware that encrypts files and demands payment for access."
        ));
        questionList.add(new Question(
                "Which of the following helps secure accounts?",
                "Using weak passwords", "Two-factor authentication", "Sharing passwords",
                1, "Two-factor authentication adds an extra layer of account security."
        ));
        questionList.add(new Question(
                "What is a strong password?",
                "123456", "A mix of letters, numbers, symbols", "Only lowercase letters",
                1, "A strong password uses a mix of uppercase, lowercase, numbers, and special symbols."
        ));
        questionList.add(new Question(
                "What is malware?",
                "A type of antivirus", "Malicious software", "Network hardware",
                1, "Malware is malicious software that can harm a system or network."
        ));
        questionList.add(new Question(
                "What is the purpose of encryption?",
                "Protecting data privacy", "Deleting files", "Blocking websites",
                0, "Encryption secures data by converting it into unreadable formats."
        ));
        questionList.add(new Question(
                "What should you check before clicking a link?",
                "Link length", "URL legitimacy", "Number of characters",
                1, "Always check the URL to verify its legitimacy before clicking."
        ));
        questionList.add(new Question(
                "What is a common sign of phishing emails?",
                "Perfect grammar", "Urgent requests", "Verified email domain",
                1, "Phishing emails often use urgency to trick users into taking action."
        ));
        questionList.add(new Question(
                "What is social engineering?",
                "Network hardware manipulation", "Manipulating people for data", "Software update technique",
                1, "Social engineering manipulates people into revealing sensitive information."
        ));
        questionList.add(new Question(
                "What is a brute force attack?",
                "Guessing passwords repeatedly", "Deleting all files", "Blocking user accounts",
                0, "A brute force attack tries many password guesses to break into accounts."
        ));
        questionList.add(new Question(
                "What does HTTPS stand for?",
                "Hyper Text Transfer Protocol Secure", "Highly Trusted Transfer Protocol Standard", "High-level Text Secure Protocol",
                0, "HTTPS ensures secure communication by encrypting data transfer."
        ));
        questionList.add(new Question(
                "What is multi-factor authentication (MFA)?",
                "One-step password login", "Multiple verification methods for login", "Encrypting accounts",
                1, "MFA uses multiple methods (e.g., SMS code, app) for identity verification."
        ));
        questionList.add(new Question(
                "What is spyware?",
                "Malware that steals user data", "Software that fixes computers", "A firewall tool",
                0, "Spyware is malware designed to secretly gather user information."
        ));
        questionList.add(new Question(
                "Which of these is a social engineering technique?",
                "Phishing emails", "System updates", "Firewall installation",
                0, "Phishing emails are a common social engineering attack method."
        ));
        questionList.add(new Question(
                "What is the purpose of a password manager?",
                "Encrypting user emails", "Generating and storing strong passwords", "Deleting weak passwords",
                1, "Password managers help create and securely store complex passwords."
        ));
        questionList.add(new Question(
                "What is a DoS attack?",
                "Data Overload Solution", "Denial of Service", "Domain Operation System",
                1, "A Denial of Service (DoS) attack overwhelms a system to make it unavailable."
        ));
        questionList.add(new Question(
                "What does an antivirus do?",
                "Infect computers with malware", "Protect against malware", "Speed up internet connection",
                1, "Antivirus software detects and removes malware threats."
        ));
        questionList.add(new Question(
                "What is an insider threat?",
                "Malware from external hackers", "A threat from within the organization", "A global cyber-attack",
                1, "Insider threats come from employees or trusted insiders misusing access."
        ));
        questionList.add(new Question(
                "What is a zero-day vulnerability?",
                "A patched system issue", "An unpatched and unknown software flaw", "A deleted software bug",
                1, "Zero-day vulnerabilities are unknown flaws that attackers exploit."
        ));
        questionList.add(new Question(
                "What does two-step verification require?",
                "Username only", "Password and additional code", "Email only",
                1, "Two-step verification requires a password plus a second code or method."
        ));
        questionList.add(new Question(
                "What is a man-in-the-middle attack?",
                "Intercepting communication between two parties", "Directly attacking a server", "Sending phishing emails",
                0, "Man-in-the-middle attacks intercept and alter communication between two parties."
        ));
        questionList.add(new Question(
                "How can you identify a fake website?",
                "Check for HTTPS", "Rely on random links", "Count the images",
                0, "Legitimate websites often use HTTPS for secure connections."
        ));
        questionList.add(new Question(
                "What is ethical hacking?",
                "Hacking with malicious intent", "Authorized hacking to find vulnerabilities", "Hacking for profit",
                1, "Ethical hacking is authorized testing to improve security."
        ));
    }


    private static class Question {
        private final String question, option1, option2, option3, explanation;
        private final int correctAnswer;

        public Question(String question, String option1, String option2, String option3, int correctAnswer, String explanation) {
            this.question = question;
            this.option1 = option1;
            this.option2 = option2;
            this.option3 = option3;
            this.correctAnswer = correctAnswer;
            this.explanation = explanation;
        }

        public String getQuestion() {
            return question;
        }

        public String getOption1() {
            return option1;
        }

        public String getOption2() {
            return option2;
        }

        public String getOption3() {
            return option3;
        }

        public int getCorrectAnswer() {
            return correctAnswer;
        }

        public String getExplanation() {
            return explanation;
        }
    }
}
