package com.example.cybersafebasics;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class CyberNewsActivity extends AppCompatActivity {

    private RecyclerView recyclerNews;
    private NewsAdapter newsAdapter;
    private ProgressBar progressBar;
    private List<NewsItem> newsList = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cyber_news);

        recyclerNews = findViewById(R.id.recyclerNews);
        progressBar = findViewById(R.id.progressBar);

        recyclerNews.setLayoutManager(new LinearLayoutManager(this));
        newsAdapter = new NewsAdapter(newsList);
        recyclerNews.setAdapter(newsAdapter);

        fetchNews();
    }

    private void fetchNews() {
        progressBar.setVisibility(View.VISIBLE);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://newsapi.org/v2/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        NewsAPI service = retrofit.create(NewsAPI.class);

        Call<NewsResponse> call = service.getCybersecurityNews("cybersecurity", "2e571a0073844234b916d94a86491a92");
        call.enqueue(new Callback<NewsResponse>() {
            @Override
            public void onResponse(Call<NewsResponse> call, Response<NewsResponse> response) {
                progressBar.setVisibility(View.GONE);
                if (response.isSuccessful() && response.body() != null) {
                    newsList.clear();
                    for (NewsResponse.Article article : response.body().getArticles()) {
                        newsList.add(new NewsItem(article.getTitle(), article.getDescription(), article.getPublishedAt()));
                    }
                    newsAdapter.notifyDataSetChanged();
                } else {
                    Toast.makeText(CyberNewsActivity.this, "Failed to fetch news", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<NewsResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(CyberNewsActivity.this, "Error: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
