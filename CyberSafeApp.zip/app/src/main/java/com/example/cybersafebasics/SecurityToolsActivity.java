package com.example.cybersafebasics;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class SecurityToolsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_security_tools);

        Button btnAppSecurityAnalyzer = findViewById(R.id.btnAppSecurityAnalyzer);
        Button btnAntiMalware = findViewById(R.id.btnAntiMalware);
        Button btnParentalControl = findViewById(R.id.btnParentalControl);

        btnAppSecurityAnalyzer.setOnClickListener(v -> {
            Intent intent = new Intent(SecurityToolsActivity.this, AppSecurityAnalyzerActivity.class);
            startActivity(intent);
        });

        btnAntiMalware.setOnClickListener(v -> {
            Intent intent = new Intent(SecurityToolsActivity.this, AntiMalwareActivity.class);
            startActivity(intent);
        });

        btnParentalControl.setOnClickListener(v -> {
            Intent intent = new Intent(SecurityToolsActivity.this, ParentalControlActivity.class);
            startActivity(intent);
        });
    }
}
