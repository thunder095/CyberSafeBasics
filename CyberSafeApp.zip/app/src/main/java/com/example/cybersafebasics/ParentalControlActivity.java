package com.example.cybersafebasics;

import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ParentalControlActivity extends AppCompatActivity {

    private static final String PARENTAL_CODE = "0000";

    private PackageManager pm;
    private Map<String, Long> appScreenTimeLimits = new HashMap<>();
    private Map<String, Long> appCurrentUsage = new HashMap<>();
    private ListView usageListView;
    private List<String> blockedApps = new ArrayList<>();
    private ArrayAdapter<String> usageAdapter;
    private BarChart barChart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parental_control);

        pm = getPackageManager();

        Button btnSetScreenTime = findViewById(R.id.btnSetScreenTime);
        Button btnBlockApps = findViewById(R.id.btnBlockApps);
        Button btnMonitorUsage = findViewById(R.id.btnMonitorUsage);
        usageListView = findViewById(R.id.usageListView);
        barChart = findViewById(R.id.barChart);

        btnMonitorUsage.setOnClickListener(v -> {
            if (!hasUsagePermission()) {
                requestUsagePermission();
                return;
            }

            fetchAppUsageStats();
            displayAppUsage();
            drawUsageGraph();
        });

        btnSetScreenTime.setOnClickListener(v -> showAppListDialog("Set Screen Time", true));
        btnBlockApps.setOnClickListener(v -> showAppListDialog("Block Apps", false));
    }

    private void fetchAppUsageStats() {
        appCurrentUsage.clear();
        UsageStatsManager usm = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
        Calendar end = Calendar.getInstance();
        Calendar start = Calendar.getInstance();
        start.add(Calendar.DAY_OF_MONTH, -1);

        List<UsageStats> stats = usm.queryUsageStats(
                UsageStatsManager.INTERVAL_DAILY,
                start.getTimeInMillis(),
                end.getTimeInMillis()
        );

        if (stats != null) {
            for (UsageStats usage : stats) {
                try {
                    ApplicationInfo ai = pm.getApplicationInfo(usage.getPackageName(), 0);
                    String appName = pm.getApplicationLabel(ai).toString();
                    long totalTime = usage.getTotalTimeInForeground();
                    if (totalTime > 0) {
                        appCurrentUsage.put(appName, totalTime);
                    }
                } catch (PackageManager.NameNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void drawUsageGraph() {
        List<BarEntry> entries = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        int index = 0;

        for (Map.Entry<String, Long> entry : appCurrentUsage.entrySet()) {
            float seconds = entry.getValue() / 1000f;
            entries.add(new BarEntry(index, seconds));
            labels.add(entry.getKey());
            index++;
        }

        BarDataSet dataSet = new BarDataSet(entries, "App Usage (Seconds)");
        dataSet.setColors(Color.RED, Color.BLUE, Color.GREEN);
        BarData barData = new BarData(dataSet);

        barChart.setData(barData);
        barChart.setFitBars(true);
        barChart.getDescription().setText("App Usage Summary");
        barChart.getDescription().setTextSize(12f);

        XAxis xAxis = barChart.getXAxis();
        xAxis.setGranularity(1f);
        xAxis.setGranularityEnabled(true);
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);

        barChart.invalidate(); // Refresh
    }

    private void displayAppUsage() {
        List<String> usageDisplay = new ArrayList<>();
        for (Map.Entry<String, Long> entry : appCurrentUsage.entrySet()) {
            String app = entry.getKey();
            long usage = entry.getValue();
            String entryDisplay = app + " - " + (usage / 60000) + " mins";

            if (appScreenTimeLimits.containsKey(app)) {
                long limit = appScreenTimeLimits.get(app);
                entryDisplay += " / Limit: " + (limit / 60000) + " mins";
                if (usage >= limit) {
                    entryDisplay += " ⚠️";
                }
            }

            if (blockedApps.contains(app)) {
                entryDisplay += " 🔒";
            }

            usageDisplay.add(entryDisplay);
        }

        usageAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, usageDisplay);
        usageListView.setAdapter(usageAdapter);
    }

    private void showAppListDialog(String title, boolean isTimeLimit) {
        List<ApplicationInfo> allApps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        List<ApplicationInfo> apps = new ArrayList<>();
        for (ApplicationInfo app : allApps) {
            if ((app.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
                apps.add(app);
            }
        }

        String[] appNames = new String[apps.size()];
        for (int i = 0; i < apps.size(); i++) {
            appNames[i] = apps.get(i).loadLabel(pm).toString();
        }

        new AlertDialog.Builder(this)
                .setTitle(title)
                .setItems(appNames, (dialog, which) -> {
                    String selectedApp = appNames[which];

                    if (isTimeLimit) {
                        EditText input = new EditText(this);
                        input.setHint("Enter time in minutes");
                        input.setInputType(InputType.TYPE_CLASS_NUMBER);
                        new AlertDialog.Builder(this)
                                .setTitle("Set Time Limit for " + selectedApp)
                                .setView(input)
                                .setPositiveButton("Set", (d, w) -> {
                                    long timeLimit = Long.parseLong(input.getText().toString()) * 60 * 1000;
                                    appScreenTimeLimits.put(selectedApp, timeLimit);
                                    Toast.makeText(this, "Time limit set!", Toast.LENGTH_SHORT).show();
                                })
                                .setNegativeButton("Cancel", null)
                                .show();
                    } else {
                        promptParentalCode(success -> {
                            if (success) {
                                if (blockedApps.contains(selectedApp)) {
                                    blockedApps.remove(selectedApp);
                                    Toast.makeText(this, selectedApp + " unblocked", Toast.LENGTH_SHORT).show();
                                } else {
                                    blockedApps.add(selectedApp);
                                    Toast.makeText(this, selectedApp + " blocked", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(this, "Incorrect code", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                })
                .show();
    }

    private void promptParentalCode(OnCodeEnteredListener listener) {
        EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        input.setHint("Enter 4-digit code");

        new AlertDialog.Builder(this)
                .setTitle("Enter Parental Code")
                .setView(input)
                .setPositiveButton("Submit", (dialog, which) -> {
                    String code = input.getText().toString();
                    listener.onCodeEntered(code.equals(PARENTAL_CODE));
                })
                .setNegativeButton("Cancel", (dialog, which) -> listener.onCodeEntered(false))
                .show();
    }

    private boolean hasUsagePermission() {
        UsageStatsManager usm = (UsageStatsManager) getSystemService(USAGE_STATS_SERVICE);
        long currentTime = System.currentTimeMillis();
        List<UsageStats> stats = usm.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, currentTime - 1000 * 60, currentTime);
        return stats != null && !stats.isEmpty();
    }

    private void requestUsagePermission() {
        startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
        Toast.makeText(this, "Please grant usage access", Toast.LENGTH_LONG).show();
    }

    interface OnCodeEnteredListener {
        void onCodeEntered(boolean success);
    }
}
