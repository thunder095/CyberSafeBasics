package com.example.cybersafebasics;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class SecureTabFragment extends Fragment {

    private static final String ARG_URL = "arg_url";

    public static SecureTabFragment newInstance(String url) {
        SecureTabFragment fragment = new SecureTabFragment();
        Bundle args = new Bundle();
        args.putString(ARG_URL, url);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        WebView webView = new WebView(requireContext());
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setUserAgentString("SecureBrowser/1.0");

        webView.setWebViewClient(new AdBlockWebViewClient());

        if (getArguments() != null) {
            webView.loadUrl(getArguments().getString(ARG_URL));
        }

        return webView;
    }

    static class AdBlockWebViewClient extends WebViewClient {
        private final String[] adHosts = {
                "ads", "doubleclick", "googlesyndication", "adservice"
        };

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return false;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            for (String adHost : adHosts) {
                if (url.contains(adHost)) {
                    view.stopLoading();
                    break;
                }
            }
            super.onPageStarted(view, url, favicon);
        }
    }
}
